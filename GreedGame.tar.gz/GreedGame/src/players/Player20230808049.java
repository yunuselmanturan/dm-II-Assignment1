package players;

import game.*;
import java.util.List;
import java.util.Random;

public class Player20230808049 extends Player {
    private static final int MONTE_CARLO_PLAYOUTS = 12;   // Number of random playouts per candidate move
    private static final int MONTE_CARLO_MAX_STEPS = 200; // Max steps in each random playout
    private final Random random;

    public Player20230808049(Board board) {
        super(board);
        this.random = new Random();
    }

    @Override
    public Move nextMove() {
        List<Move> possibleMoves = board.getPossibleMoves();
        if (possibleMoves.isEmpty()) {
            return null;  // No moves => game over
        }

        Move bestMove = null;
        double bestAverageCoverage = -1.0;

        // Evaluate each candidate move via Monte Carlo playouts
        for (Move move : possibleMoves) {
            // Simulate the move on a copy
            Board boardCopy = new Board(board);
            if (!boardCopy.applyMove(move)) {
                // Shouldn't happen if it's in getPossibleMoves, but skip if invalid
                continue;
            }

            // Run several random playouts from this new state
            double totalCoverage = 0.0;
            for (int i = 0; i < MONTE_CARLO_PLAYOUTS; i++) {
                // We want a fresh copy each time
                Board playoutBoard = new Board(boardCopy);
                int coverage = randomPlayout(playoutBoard, MONTE_CARLO_MAX_STEPS);
                totalCoverage += coverage;
            }

            // Compute average coverage from these playouts
            double avgCoverage = totalCoverage / MONTE_CARLO_PLAYOUTS;
            if (avgCoverage > bestAverageCoverage) {
                bestAverageCoverage = avgCoverage;
                bestMove = move;
            }
        }

        return bestMove != null ? bestMove : possibleMoves.get(0);
    }

    /**
     * Performs a random playout starting from the given board state:
     *   - At each step, pick a random valid move from the possible moves.
     *   - Apply it until no moves remain or we hit maxSteps.
     * Returns the coverage (number of visited squares) at the end.
     */
    private int randomPlayout(Board b, int maxSteps) {
        int steps = 0;
        while (!b.isGameOver() && steps < maxSteps) {
            List<Move> moves = b.getPossibleMoves();
            if (moves.isEmpty()) {
                break;
            }
            Move randomMove = moves.get(random.nextInt(moves.size()));
            b.applyMove(randomMove);
            steps++;
        }
        return b.getScore(); 
    }
}
